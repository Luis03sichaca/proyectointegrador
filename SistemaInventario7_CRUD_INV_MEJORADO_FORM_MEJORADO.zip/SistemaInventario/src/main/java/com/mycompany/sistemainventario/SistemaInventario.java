/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemainventario;

/**
 *
 * @author fd
 */
import database.DatabaseConnection;
import javax.swing.SwingUtilities;
import view.formInicio;

public class SistemaInventario {
    public static void main(String[] args) {
        System.out.println("Iniciando la aplicación SistemaInventario...");
        
        // Opcional: Probar la conexión a la base de datos al iniciar
        DatabaseConnection.probarConexion();
        
        // Aquí podrías iniciar la interfaz gráfica de la aplicación o cualquier otra configuración inicial
        
                // Iniciar la GUI en el hilo de eventos de Swing
        SwingUtilities.invokeLater(() -> {
            formInicio inicio = new formInicio();  // Crea una instancia de formInicio
            inicio.setVisible(true);               // Hace visible el formulario formInicio
        });
    }
}
