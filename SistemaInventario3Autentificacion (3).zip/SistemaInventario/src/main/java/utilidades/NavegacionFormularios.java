/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilidades;

/**
 *
 * @author user
 */

import javax.swing.JFrame;

public class NavegacionFormularios {

    public static void regresarFormulario(JFrame actual, JFrame anterior) {
        actual.dispose();  // Cierra el formulario actual
        anterior.setVisible(true);  // Muestra el formulario anterior
    }
}
