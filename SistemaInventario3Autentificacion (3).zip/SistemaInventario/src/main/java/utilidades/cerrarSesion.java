/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilidades;

/**
 *
 * @author user
 */

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class cerrarSesion {

    // Método estático para cerrar la sesión y la aplicación
    public static void cerrarSesion(JFrame formularioActual) {
        // Mostrar un cuadro de diálogo de confirmación
        int confirmacion = JOptionPane.showConfirmDialog(
            formularioActual,
            "¿Estás seguro de que deseas cerrar sesión y salir de la aplicación?",
            "Confirmar Cierre de Sesión",
            JOptionPane.YES_NO_OPTION
        );

        // Verificar si el usuario confirmó
        if (confirmacion == JOptionPane.YES_OPTION) {
            formularioActual.dispose(); // Cerrar el formulario actual
            System.exit(0); // Cerrar la aplicación
        }
    }
}