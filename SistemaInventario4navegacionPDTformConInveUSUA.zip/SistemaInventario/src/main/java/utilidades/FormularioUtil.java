/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilidades;

import javax.swing.JFrame;

/**
 *
 * @author user
 */
public class FormularioUtil {

    // Método para abrir un nuevo formulario
    public static void abrirFormulario(JFrame formulario) {
        formulario.setVisible(true); // Hacer visible el nuevo formulario
        // Si deseas cerrar el formulario actual, puedes usar:
        // ((JFrame) SwingUtilities.getWindowAncestor(formulario)).dispose();
    }
}
